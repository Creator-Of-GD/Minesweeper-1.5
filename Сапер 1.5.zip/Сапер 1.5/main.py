# main.py
import pygame
from sound import SoundManager, MusicPlayer
from ui import Menu
from game import Game  # <-- этот импорт должен быть
import config


def main():
    pygame.init()
    sound = SoundManager()
    music = MusicPlayer()

    while True:
        screen = pygame.display.set_mode((700, 550))
        pygame.display.set_caption("Сапёр")
        diff = Menu(screen, music, sound).run()

        if diff == 'custom':
            custom_params = (config.CUSTOM_SIZE_X, config.CUSTOM_SIZE_Y, config.CUSTOM_MINES_PERCENT)
            game = Game(diff, sound, custom_params)
        else:
            game = Game(diff, sound)

        result = game.run()
        if result != 'menu':
            break


if __name__ == "__main__":
    main()