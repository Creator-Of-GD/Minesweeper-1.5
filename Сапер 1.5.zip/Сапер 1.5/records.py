# records.py
import json, os

RECORDS_FILE = "records.json"


def load_records():
    if os.path.exists(RECORDS_FILE):
        try:
            with open(RECORDS_FILE, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}


def save_records(records):
    with open(RECORDS_FILE, 'w') as f:
        json.dump(records, f)


def update_record(difficulty, time_spent):
    records = load_records()
    if difficulty not in records or time_spent < records[difficulty]:
        records[difficulty] = time_spent
        save_records(records)
        return True
    return False


