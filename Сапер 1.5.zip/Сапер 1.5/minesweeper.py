# minesweeper.py
import random, time, pygame
from config import TILE_SIZE

class Particle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vx = random.uniform(-5,5)
        self.vy = random.uniform(-5,5)
        self.lifetime = 30
        self.size = random.randint(2,5)
        self.color = (random.randint(200,255), random.randint(50,150), 0)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.3
        self.lifetime -= 1
        return self.lifetime > 0

    def draw(self, screen):
        alpha = self.lifetime / 30
        c = (int(self.color[0]*alpha), int(self.color[1]*alpha), 0)
        pygame.draw.circle(screen, c, (int(self.x), int(self.y)), self.size)

class Minesweeper:
    def __init__(self, width, height, mines, sound_manager):
        self.width = width
        self.height = height
        self.mines = mines
        self.sound_manager = sound_manager
        self.board = [[0]*width for _ in range(height)]
        self.revealed = [[False]*width for _ in range(height)]
        self.flags = [[False]*width for _ in range(height)]
        self.game_over = False
        self.won = False
        self.was_explosion = False   # <-- НОВОЕ: флаг взрыва
        self.first_move = True
        self.start_time = None
        self.end_time = None
        self.explosion_animation = False
        self.explosion_particles = []
        self.explosion_mine_pos = None
        self.fade_alpha = 0
        self.explosion_start_time = 0

    def is_valid(self, r, c):
        return 0 <= r < self.height and 0 <= c < self.width

    def get_neighbors(self, r, c):
        res = []
        for dr in (-1,0,1):
            for dc in (-1,0,1):
                if dr==0 and dc==0: continue
                nr, nc = r+dr, c+dc
                if self.is_valid(nr, nc):
                    res.append((nr, nc))
        return res

    def recalc_numbers(self):
        for r in range(self.height):
            for c in range(self.width):
                if self.board[r][c] != -1:
                    cnt = sum(1 for nr,nc in self.get_neighbors(r,c) if self.board[nr][nc] == -1)
                    self.board[r][c] = cnt

    def place_mines(self, except_cell=None):
        self.board = [[0]*self.width for _ in range(self.height)]
        possible = [(r,c) for r in range(self.height) for c in range(self.width)
                    if except_cell is None or (r,c) != except_cell]
        positions = random.sample(possible, self.mines)
        for r,c in positions:
            self.board[r][c] = -1
        self.recalc_numbers()

    def move_mine(self, r, c):
        empty = [(rr,cc) for rr in range(self.height) for cc in range(self.width)
                 if self.board[rr][cc] != -1 and not self.revealed[rr][cc]]
        if empty:
            nr, nc = random.choice(empty)
            self.board[r][c] = 0
            self.board[nr][nc] = -1
            self.recalc_numbers()

    def reveal(self, r, c):
        if self.game_over or self.won: return
        if self.revealed[r][c] or self.flags[r][c]: return

        self.sound_manager.play('click')

        if self.first_move:
            self.first_move = False
            self.start_time = time.time()
            self.place_mines(except_cell=(r,c))
            if self.board[r][c] == -1:
                self.move_mine(r,c)
            self._reveal_recursive(r,c)
            self.check_win()
            return

        if self.board[r][c] == -1:
            self.game_over = True
            self.won = False
            self.was_explosion = True   # <-- НОВОЕ: запоминаем, что это был взрыв
            self.sound_manager.play('explosion')
            self.explosion_animation = True
            self.explosion_mine_pos = (r,c)
            self.explosion_start_time = time.time()
            self.end_time = time.time()
            self.reveal_all_mines()
            return

        self._reveal_recursive(r,c)
        self.check_win()

    def _reveal_recursive(self, r, c):
        if not self.is_valid(r,c): return
        if self.revealed[r][c] or self.flags[r][c]: return
        if self.board[r][c] == -1: return
        self.revealed[r][c] = True
        if self.board[r][c] == 0:
            for nr,nc in self.get_neighbors(r,c):
                self._reveal_recursive(nr,nc)

    def toggle_flag(self, r, c):
        if self.game_over or self.won: return
        if self.revealed[r][c]: return
        self.flags[r][c] = not self.flags[r][c]
        self.sound_manager.play('flag')
        self.check_win()

    def reveal_all_mines(self):
        for r in range(self.height):
            for c in range(self.width):
                if self.board[r][c] == -1:
                    self.revealed[r][c] = True

    def check_win(self):
        unrevealed_safe = sum(1 for r in range(self.height) for c in range(self.width)
                              if not self.revealed[r][c] and self.board[r][c] != -1)
        if unrevealed_safe == 0:
            self.won = True
            self.game_over = True
            self.end_time = time.time()
            self.sound_manager.play('win')

    def update_explosion_animation(self):
        if not self.explosion_animation:
            return False
        if len(self.explosion_particles) < 300 and time.time() - self.explosion_start_time < 0.5:
            for _ in range(20):
                if self.explosion_mine_pos:
                    x = self.explosion_mine_pos[1]*TILE_SIZE + TILE_SIZE//2
                    y = self.explosion_mine_pos[0]*TILE_SIZE + TILE_SIZE//2 + 50
                    self.explosion_particles.append(Particle(x,y))
        self.explosion_particles = [p for p in self.explosion_particles if p.update()]
        if len(self.explosion_particles) == 0 and time.time() - self.explosion_start_time > 1.0:
            self.explosion_animation = False
            return True
        return False

    def draw_explosion(self, screen):
        for p in self.explosion_particles:
            p.draw(screen)

    def update_fade(self, target, speed=10):
        if self.fade_alpha < target:
            self.fade_alpha = min(target, self.fade_alpha + speed)
        elif self.fade_alpha > target:
            self.fade_alpha = max(target, self.fade_alpha - speed)
        return self.fade_alpha == target

    def draw_fade(self, screen):
        if self.fade_alpha > 0:
            s = pygame.Surface(screen.get_size())
            s.fill((0,0,0))
            s.set_alpha(self.fade_alpha)
            screen.blit(s, (0,0))

    def reset(self):
        self.board = [[0]*self.width for _ in range(self.height)]
        self.revealed = [[False]*self.width for _ in range(self.height)]
        self.flags = [[False]*self.width for _ in range(self.height)]
        self.game_over = False
        self.won = False
        self.was_explosion = False   # <-- НОВОЕ: сбрасываем флаг
        self.first_move = True
        self.start_time = None
        self.end_time = None
        self.explosion_animation = False
        self.explosion_particles = []
        self.explosion_mine_pos = None
        self.fade_alpha = 0

    def get_time(self):
        if self.start_time is None:
            return 0
        if self.end_time is not None:
            return int(self.end_time - self.start_time)
        return int(time.time() - self.start_time)