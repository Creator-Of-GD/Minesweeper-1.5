# game.py
import pygame
import sys
import random
import math
import config
from config import TILE_SIZE, FPS, DIFFICULTY_SETTINGS, get_colors, SMILE_COLORS, SCREAMER_CHANCE
from minesweeper import Minesweeper
from ui import Button, GameOverMenu
from records import update_record


class Game:
    def __init__(self, difficulty, sound_manager, custom_params=None):
        self.difficulty = difficulty
        self.sound_manager = sound_manager
        self.colors = get_colors()

        if difficulty == 'custom':
            if custom_params:
                w, h, percent = custom_params
            else:
                w = 10
                h = 10
                percent = 10
            self.width = w
            self.height = h
            self.mines = int(w * h * percent / 100)
            if self.mines < 1:
                self.mines = 1
            self.diff_name = "Кастомное"
            self.diff_key = 'custom'
        else:
            self.width = DIFFICULTY_SETTINGS[difficulty]['width']
            self.height = DIFFICULTY_SETTINGS[difficulty]['height']
            self.mines = DIFFICULTY_SETTINGS[difficulty]['mines']
            self.diff_name = DIFFICULTY_SETTINGS[difficulty]['name']
            self.diff_key = difficulty

        self.minesweeper = Minesweeper(self.width, self.height, self.mines, sound_manager)
        self.screen_width = self.width * TILE_SIZE
        self.screen_height = self.height * TILE_SIZE + 100
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption(f"Сапёр - {self.diff_name} режим")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 32)
        self.small_font = pygame.font.Font(None, 20)

        # Новая кнопка (без цветов)
        self.new_btn = Button(
            self.screen_width // 2 + 40, 10, 80, 30,
            "Новая", self.small_font
        )
        self.show_game_over_menu = False
        self.controls_hint = "ЛКМ - открыть, ПКМ - флаг"

        # Переменные для скримера
        self.screamer_active = False
        self.screamer_start_time = 0
        self.screamer_triggered = False

    def draw_screamer(self):
        """Рисует жуткий смайл на весь экран"""
        if not self.screamer_active:
            return

        screen_w = self.screen.get_width()
        screen_h = self.screen.get_height()

        # Жуткий фон
        self.screen.fill((20, 0, 0))

        center_x = screen_w // 2
        center_y = screen_h // 2
        radius = min(screen_w, screen_h) // 2 - 40

        # Лицо
        pygame.draw.circle(self.screen, (255, 255, 0), (center_x, center_y), radius)

        # Глаза - красные с чёрными зрачками
        eye_radius = radius // 4
        eye_offset = radius // 3

        # Левый глаз
        pygame.draw.circle(self.screen, (255, 0, 0), (center_x - eye_offset, center_y - 20), eye_radius)
        pygame.draw.circle(self.screen, (0, 0, 0), (center_x - eye_offset + 5, center_y - 15), eye_radius // 2)

        # Правый глаз
        pygame.draw.circle(self.screen, (255, 0, 0), (center_x + eye_offset, center_y - 20), eye_radius)
        pygame.draw.circle(self.screen, (0, 0, 0), (center_x + eye_offset + 5, center_y - 15), eye_radius // 2)

        # Рот - зловещая улыбка
        mouth_rect = pygame.Rect(center_x - radius // 2, center_y + 10, radius, radius // 2)
        pygame.draw.arc(self.screen, (0, 0, 0), mouth_rect, 0, 3.14, 4)

        # Зубы (исправлены: tooth_width и tooth_height теперь > 0)
        tooth_width = 0
        tooth_height = 0
        for i in range(-3, 4):
            x = center_x + i * tooth_width
            points = [
                (x, center_y + 0),
                (x + tooth_width // 2, center_y + 0 + tooth_height),
                (x + tooth_width, center_y + 0)
            ]
            pygame.draw.polygon(self.screen, (255, 255, 255), points)

        # Кровавые линии вокруг глаз
        for angle in [0, 45, 90, 135, 180, 225, 270, 315]:
            rad = math.radians(angle)
            x1 = center_x - eye_offset + int(eye_radius * 1.2 * math.cos(rad))
            y1 = center_y - 20 + int(eye_radius * 1.2 * math.sin(rad))
            x2 = center_x - eye_offset + int(eye_radius * 2.5 * math.cos(rad))
            y2 = center_y - 20 + int(eye_radius * 2.5 * math.sin(rad))
            pygame.draw.line(self.screen, (150, 0, 0), (x1, y1), (x2, y2), 3)

        for angle in [0, 45, 90, 135, 180, 225, 270, 315]:
            rad = math.radians(angle)
            x1 = center_x + eye_offset + int(eye_radius * 1.2 * math.cos(rad))
            y1 = center_y - 20 + int(eye_radius * 1.2 * math.sin(rad))
            x2 = center_x + eye_offset + int(eye_radius * 2.5 * math.cos(rad))
            y2 = center_y - 20 + int(eye_radius * 2.5 * math.sin(rad))
            pygame.draw.line(self.screen, (150, 0, 0), (x1, y1), (x2, y2), 3)

        # Надпись
        font_big = pygame.font.Font(None, 80)
        text = font_big.render("ТЫ УМРЁШЬ", True, (255, 0, 0))
        text_rect = text.get_rect(center=(center_x, 60))
        self.screen.blit(text, text_rect)

    def draw_smile(self):
        cx = self.screen_width // 2
        cy = 25
        c = SMILE_COLORS

        if self.minesweeper.won:
            pygame.draw.circle(self.screen, c['face'], (cx, cy), 15)
            pygame.draw.circle(self.screen, c['eye'], (cx - 5, cy - 5), 2)
            pygame.draw.circle(self.screen, c['eye'], (cx + 5, cy - 5), 2)
            pygame.draw.arc(self.screen, c['mouth'], (cx - 10, cy - 5, 20, 15), 3.14, 6.28, 2)
            pygame.draw.circle(self.screen, c['pupil'], (cx - 9, cy - 7), 4)
            pygame.draw.circle(self.screen, c['pupil'], (cx + 9, cy - 7), 4)
            pygame.draw.line(self.screen, c['pupil'], (cx - 5, cy - 7), (cx + 5, cy - 7), 2)
        elif self.minesweeper.game_over and not self.minesweeper.won:
            pygame.draw.circle(self.screen, c['face'], (cx, cy), 15)
            x1, y1 = cx - 5, cy - 5
            size = 3
            pygame.draw.line(self.screen, c['eye'], (x1 - size, y1 - size), (x1 + size, y1 + size), 2)
            pygame.draw.line(self.screen, c['eye'], (x1 + size, y1 - size), (x1 - size, y1 + size), 2)
            x2, y2 = cx + 5, cy - 5
            pygame.draw.line(self.screen, c['eye'], (x2 - size, y2 - size), (x2 + size, y2 + size), 2)
            pygame.draw.line(self.screen, c['eye'], (x2 + size, y2 - size), (x2 - size, y2 + size), 2)
            pygame.draw.arc(self.screen, c['mouth'], (cx - 10, cy + 2, 20, 15), 0, 3.14, 2)
        else:
            pygame.draw.circle(self.screen, c['face'], (cx, cy), 15)
            pygame.draw.circle(self.screen, c['eye'], (cx - 5, cy - 5), 2)
            pygame.draw.circle(self.screen, c['eye'], (cx + 5, cy - 5), 2)
            pygame.draw.arc(self.screen, c['mouth'], (cx - 8, cy - 3, 16, 12), 3.14, 6.28, 2)

    def draw_board(self):
        # Если активен скример - рисуем только его
        if self.screamer_active:
            self.draw_screamer()
            return

        self.screen.fill(self.colors['bg'])
        pygame.draw.rect(self.screen, self.colors['panel_bg'], (0, 0, self.screen_width, 50))
        pygame.draw.line(self.screen, self.colors['panel_border'], (0, 50), (self.screen_width, 50), 2)

        fl = sum(sum(row) for row in self.minesweeper.flags)
        rem = max(0, self.mines - fl)
        txt = self.font.render(f"{rem:03d}", True, (255, 0, 0))
        self.screen.blit(txt, (10, 13))

        tm = self.font.render(f"{self.minesweeper.get_time():03d}", True, (255, 0, 0))
        tr = tm.get_rect(right=self.screen_width - 10, top=13)
        self.screen.blit(tm, tr)

        self.draw_smile()
        self.new_btn.draw(self.screen, self.colors)  # <-- передаём цвета

        h = self.small_font.render(self.controls_hint, True, self.colors['text'])
        hr = h.get_rect(center=(self.screen_width // 2, 70))
        self.screen.blit(h, hr)

        for row in range(self.height):
            for col in range(self.width):
                x = col * TILE_SIZE
                y = row * TILE_SIZE + 50
                rect = pygame.Rect(x, y, TILE_SIZE, TILE_SIZE)

                if self.minesweeper.revealed[row][col]:
                    if self.minesweeper.explosion_mine_pos == (row, col) and self.minesweeper.explosion_animation:
                        intensity = (pygame.time.get_ticks() % 200) / 200
                        color = (255, int(100 * (1 - intensity)), 0)
                        pygame.draw.rect(self.screen, color, rect)
                    else:
                        pygame.draw.rect(self.screen, self.colors['revealed'], rect)
                    pygame.draw.rect(self.screen, self.colors['border_dark'], rect, 1)

                    val = self.minesweeper.board[row][col]
                    if val > 0:
                        num = self.small_font.render(str(val), True, self.colors['numbers'][val])
                        nr = num.get_rect(center=rect.center)
                        self.screen.blit(num, nr)
                    elif val == -1:
                        if self.minesweeper.explosion_mine_pos == (row, col) and self.minesweeper.explosion_animation:
                            radius = TILE_SIZE // 2 + (pygame.time.get_ticks() % 100) / 20
                            pygame.draw.circle(self.screen, (255, 0, 0), rect.center, radius)
                        else:
                            pygame.draw.circle(self.screen, self.colors['mine'], rect.center, TILE_SIZE // 3)
                else:
                    pygame.draw.rect(self.screen, self.colors['hidden'], rect)
                    pygame.draw.line(self.screen, self.colors['border_light'], rect.topleft, rect.topright, 2)
                    pygame.draw.line(self.screen, self.colors['border_light'], rect.topleft, rect.bottomleft, 2)
                    pygame.draw.line(self.screen, self.colors['border_dark'], rect.bottomright, rect.topright, 2)
                    pygame.draw.line(self.screen, self.colors['border_dark'], rect.bottomright, rect.bottomleft, 2)

                    if self.minesweeper.flags[row][col]:
                        pts = [(x + 5, y + 5), (x + TILE_SIZE - 10, y + TILE_SIZE // 2), (x + 5, y + TILE_SIZE - 5)]
                        pygame.draw.polygon(self.screen, self.colors['flag'], pts)

        if self.minesweeper.explosion_animation:
            self.minesweeper.draw_explosion(self.screen)
        self.minesweeper.draw_fade(self.screen)

    def run(self):
        while True:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if not self.minesweeper.explosion_animation and not self.show_game_over_menu and not self.screamer_active:
                    if self.new_btn.handle_event(ev):
                        self.minesweeper.reset()
                        self.show_game_over_menu = False
                        self.screamer_active = False
                        self.screamer_triggered = False
                        continue

                    if ev.type == pygame.MOUSEBUTTONDOWN:
                        x, y = ev.pos
                        cx, cy = self.screen_width // 2, 25
                        if (x - cx) ** 2 + (y - cy) ** 2 <= 15 ** 2:
                            self.minesweeper.reset()
                            self.show_game_over_menu = False
                            self.screamer_active = False
                            self.screamer_triggered = False
                            continue

                        y -= 50
                        if 0 <= x < self.screen_width and 0 <= y < self.height * TILE_SIZE:
                            row = y // TILE_SIZE
                            col = x // TILE_SIZE
                            if 0 <= row < self.height and 0 <= col < self.width:
                                if ev.button == 1:
                                    self.minesweeper.reveal(row, col)
                                elif ev.button == 3:
                                    self.minesweeper.toggle_flag(row, col)

            # Анимация взрыва
            if self.minesweeper.explosion_animation:
                done = self.minesweeper.update_explosion_animation()
                if done:
                    # Ждём, пока fade_alpha достигнет 180
                    while self.minesweeper.fade_alpha < 180:
                        self.minesweeper.update_fade(180)
                        self.draw_board()
                        pygame.display.flip()
                        self.clock.tick(FPS)

                    if self.minesweeper.was_explosion and not self.screamer_triggered:
                        self.screamer_triggered = True
                        if config.SCREAMER_ENABLED and random.randint(1, 100) <= SCREAMER_CHANCE:
                            self.screamer_active = True
                            self.screamer_start_time = pygame.time.get_ticks()
                            self.sound_manager.play('screamer')
                            self.show_game_over_menu = False
                        else:
                            self.show_game_over_menu = True
                    else:
                        self.show_game_over_menu = True
                    self.minesweeper.explosion_animation = False
            elif self.minesweeper.game_over and not self.show_game_over_menu and not self.screamer_active:
                self.minesweeper.update_fade(180)
                if self.minesweeper.fade_alpha >= 180:
                    self.show_game_over_menu = True

            # Обработка скримера
            if self.screamer_active:
                if pygame.time.get_ticks() - self.screamer_start_time > 3000:
                    self.screamer_active = False
                    self.show_game_over_menu = True

            # Меню проигрыша/победы
            if self.show_game_over_menu:
                time_spent = self.minesweeper.get_time()
                if self.minesweeper.won:
                    update_record(self.diff_key, time_spent)
                menu = GameOverMenu(self.screen, self.minesweeper.won, time_spent,
                                    self.diff_name, self.diff_key)
                choice = menu.run()
                if choice == 'restart':
                    self.minesweeper.reset()
                    self.show_game_over_menu = False
                    self.screamer_active = False
                    self.screamer_triggered = False
                elif choice == 'menu':
                    return 'menu'

            self.draw_board()
            pygame.display.flip()
            self.clock.tick(FPS)