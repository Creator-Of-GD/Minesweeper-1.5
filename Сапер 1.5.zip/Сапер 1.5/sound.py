# sound.py
import pygame, random, math, time

class SoundManager:
    def __init__(self):
        self.sounds = {}
        self.enabled = True
        try:
            pygame.mixer.init()
            self.create_sounds()
        except:
            self.enabled = False

    def create_sounds(self):
        try:
            self.sounds['click'] = self._make_soft_beep(880, 0.03)
            self.sounds['flag'] = self._make_soft_beep(1100, 0.04)
            self.sounds['explosion'] = self._make_soft_noise(0.3)
            self.sounds['win'] = self._make_victory()
            self.sounds['screamer'] = self._make_screamer_sound()   # <-- НОВОЕ
        except:
            self.sounds = {k:None for k in ['click','flag','explosion','win','screamer']}

    def _make_soft_beep(self, freq, dur):
        try:
            sr = 8000
            n = int(sr*dur)
            arr = bytearray()
            for i in range(n):
                env = math.sin(math.pi*i/n)
                val = int(5000*env*math.sin(2*math.pi*freq*i/sr))
                val = max(-32767, min(32767, val))
                arr.extend(val.to_bytes(2,'little',signed=True))
                arr.extend(val.to_bytes(2,'little',signed=True))
            return pygame.mixer.Sound(buffer=arr)
        except:
            return None

    def _make_soft_noise(self, dur):
        try:
            sr = 8000
            n = int(sr*dur)
            arr = bytearray()
            for i in range(n):
                env = math.sin(math.pi*i/n)
                val = int(8000*env*random.uniform(-1,1))
                val = max(-32767, min(32767, val))
                arr.extend(val.to_bytes(2,'little',signed=True))
                arr.extend(val.to_bytes(2,'little',signed=True))
            return pygame.mixer.Sound(buffer=arr)
        except:
            return None

    def _make_victory(self):
        try:
            sr = 8000
            dur = 0.4
            n = int(sr*dur)
            arr = bytearray()
            for i in range(n):
                env = math.sin(math.pi*i/n)
                freq = 523 + 100*math.sin(2*math.pi*i/n*3)
                val = int(6000*env*math.sin(2*math.pi*freq*i/sr))
                val = max(-32767, min(32767, val))
                arr.extend(val.to_bytes(2,'little',signed=True))
                arr.extend(val.to_bytes(2,'little',signed=True))
            return pygame.mixer.Sound(buffer=arr)
        except:
            return None

    def _make_screamer_sound(self):
        """Генерирует громкий резкий шум для скримера"""
        try:
            sr = 8000
            dur = 1.0
            n = int(sr * dur)
            arr = bytearray()
            for i in range(n):
                envelope = min(1.0, i / (sr * 0.1))
                val = int(25000 * envelope * random.uniform(-1.5, 1.5))
                val += int(10000 * envelope * math.sin(2 * math.pi * 300 * i / sr))
                val = max(-32767, min(32767, val))
                arr.extend(val.to_bytes(2, 'little', signed=True))
                arr.extend(val.to_bytes(2, 'little', signed=True))
            s = pygame.mixer.Sound(buffer=arr)
            s.set_volume(1.0)
            return s
        except:
            return None

    def play(self, name):
        if not self.enabled:
            return
        if name in self.sounds and self.sounds[name] is not None:
            try:
                self.sounds[name].play()
            except:
                pass

class MusicPlayer:
    def __init__(self):
        self.playing = False
        self.current_note = 0
        self.last_time = 0
        self.notes = [
            (262,0.3),(294,0.3),(330,0.3),(349,0.3),
            (392,0.3),(440,0.3),(494,0.3),(523,0.3),
            (494,0.3),(440,0.3),(392,0.3),(349,0.3),
            (330,0.3),(294,0.3),(262,0.6)
        ]
        self.sounds = []
        self._prepare()

    def _prepare(self):
        for freq, dur in self.notes:
            self.sounds.append(self._make_note(freq, dur))

    def _make_note(self, freq, dur):
        try:
            sr = 8000
            n = int(sr*dur)
            arr = bytearray()
            for i in range(n):
                env = 1.0
                if i > n*0.9:
                    env = (n-i)/(n*0.1)
                val = int(5000*env*math.sin(2*math.pi*freq*i/sr))
                val = max(-32767, min(32767, val))
                arr.extend(val.to_bytes(2,'little',signed=True))
                arr.extend(val.to_bytes(2,'little',signed=True))
            s = pygame.mixer.Sound(buffer=arr)
            s.set_volume(0.25)
            return s
        except:
            return None

    def _play_note(self, idx):
        if idx < len(self.sounds) and self.sounds[idx] is not None:
            try:
                self.sounds[idx].play()
            except:
                pass

    def update(self):
        if not self.playing: return
        now = time.time()
        if now - self.last_time >= self.notes[self.current_note][1]:
            self._play_note(self.current_note)
            self.current_note = (self.current_note + 1) % len(self.notes)
            self.last_time = now

    def start(self):
        self.playing = True
        self.current_note = 0
        self.last_time = time.time()

    def stop(self):
        self.playing = False