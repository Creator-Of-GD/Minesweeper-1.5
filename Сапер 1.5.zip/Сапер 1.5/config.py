# config.py
import pygame

FPS = 60
TILE_SIZE = 30

DIFFICULTY_SETTINGS = {
    'easy':   {'width': 10, 'height': 10, 'mines': 10,  'name': 'Лёгкий'},
    'medium': {'width': 15, 'height': 15, 'mines': 27,  'name': 'Средний'},
    'hard':   {'width': 20, 'height': 20, 'mines': 60,  'name': 'Сложный'},
    'extreme':{'width': 23, 'height': 23, 'mines': 106, 'name': 'ЭКСТРИМ'}
}

# ------------------- ТЕМЫ ОФОРМЛЕНИЯ -------------------
THEMES = {
    'light': {
        'bg': (192, 192, 192),
        'hidden': (170, 170, 170),
        'revealed': (200, 200, 200),
        'border_light': (255, 255, 255),
        'border_dark': (100, 100, 100),
        'flag': (255, 0, 0),
        'mine': (0, 0, 0),
        'menu_bg': (50, 50, 50),
        'text': (255, 255, 255),
        'numbers': {
            1: (0, 0, 255), 2: (0, 128, 0), 3: (255, 0, 0),
            4: (0, 0, 128), 5: (128, 0, 0), 6: (0, 128, 128),
            7: (0, 0, 0), 8: (128, 128, 128)
        },
        'panel_bg': (192, 192, 192),
        'panel_border': (100, 100, 100),
        # Цвета кнопок
        'button_bg': (200, 200, 200),
        'button_text': (0, 0, 0),
        'button_hover_bg': (80, 80, 80),
        'button_hover_text': (255, 255, 255),
    },
    'dark': {
        'bg': (40, 40, 40),
        'hidden': (60, 60, 60),
        'revealed': (80, 80, 80),
        'border_light': (120, 120, 120),
        'border_dark': (30, 30, 30),
        'flag': (255, 50, 50),
        'mine': (200, 200, 200),
        'menu_bg': (20, 20, 20),
        'text': (220, 220, 220),
        'numbers': {
            1: (100, 150, 255), 2: (100, 220, 100), 3: (255, 100, 100),
            4: (150, 100, 255), 5: (255, 150, 100), 6: (100, 220, 220),
            7: (200, 200, 200), 8: (180, 180, 180)
        },
        'panel_bg': (40, 40, 40),
        'panel_border': (30, 30, 30),
        # Цвета кнопок
        'button_bg': (80, 80, 80),
        'button_text': (255, 255, 255),
        'button_hover_bg': (200, 200, 200),
        'button_hover_text': (0, 0, 0),
    }
}

CURRENT_THEME = 'light'

# Фиксированные цвета для смайла
SMILE_COLORS = {
    'face': (255, 255, 0),
    'eye': (0, 0, 0),
    'pupil': (0, 0, 255),
    'mouth': (0, 0, 0),
    'dead_eye': (0, 0, 255)
}

# Кастомные параметры поля
CUSTOM_SIZE_X = 10
CUSTOM_SIZE_Y = 10
CUSTOM_MINES_PERCENT = 10

# Звук и скример
SOUND_ENABLED = True
SCREAMER_ENABLED = True
SCREAMER_CHANCE = 10

def set_custom_params(width, height, percent):
    global CUSTOM_SIZE_X, CUSTOM_SIZE_Y, CUSTOM_MINES_PERCENT
    CUSTOM_SIZE_X = max(5, min(30, width))
    CUSTOM_SIZE_Y = max(5, min(30, height))
    CUSTOM_MINES_PERCENT = max(1, min(50, percent))

def get_colors():
    return THEMES[CURRENT_THEME]