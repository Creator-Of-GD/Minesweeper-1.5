# ui.py
import pygame
import sys
import config
from config import FPS, DIFFICULTY_SETTINGS, SOUND_ENABLED
from records import load_records


class Button:
    def __init__(self, x, y, w, h, text, font=None):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.font = font or pygame.font.Font(None, 24)
        self.hovered = False

    def draw(self, screen, colors):
        if self.hovered:
            bg_color = colors['button_hover_bg']
            text_color = colors['button_hover_text']
        else:
            bg_color = colors['button_bg']
            text_color = colors['button_text']

        pygame.draw.rect(screen, bg_color, self.rect)
        pygame.draw.rect(screen, (100, 100, 100), self.rect, 1)

        text_surf = self.font.render(self.text, True, text_color)
        text_rect = text_surf.get_rect(center=self.rect.center)
        screen.blit(text_surf, text_rect)

    def handle_event(self, ev):
        if ev.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(ev.pos)
        elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            if self.hovered:
                return True
        return False


class SettingsWindow:
    def __init__(self, screen, music_player, sound_manager):
        self.screen = screen
        self.music_player = music_player
        self.sound_manager = sound_manager
        self.colors = config.get_colors()
        self.font = pygame.font.Font(None, 32)
        self.small_font = pygame.font.Font(None, 24)
        self.buttons = []
        self.input_fields = []
        self.active_input = None
        self.input_texts = {
            'width': str(config.CUSTOM_SIZE_X),
            'height': str(config.CUSTOM_SIZE_Y),
            'percent': str(config.CUSTOM_MINES_PERCENT)
        }
        self.running = True

        sw, sh = screen.get_width(), screen.get_height()
        bw, bh = 200, 40

        self.buttons.append(Button(sw//2 - bw//2, 60, bw, bh, "Сменить тему", self.small_font))
        sound_text = "Звук: Вкл" if config.SOUND_ENABLED else "Звук: Выкл"
        self.buttons.append(Button(sw//2 - bw//2, 120, bw, bh, sound_text, self.small_font))
        screamer_text = "Скример: Вкл" if config.SCREAMER_ENABLED else "Скример: Выкл"
        self.buttons.append(Button(sw//2 - bw//2, 180, bw, bh, screamer_text, self.small_font))

        self.labels = [
            ("Ширина (клеток):", 240),
            ("Высота (клеток):", 280),
            ("Процент мин (%):", 320)
        ]
        self.input_rects = []
        for i, (label, y) in enumerate(self.labels):
            rect = pygame.Rect(sw//2 - 40, y - 15, 80, 30)
            self.input_rects.append(rect)
            if i == 0:
                self.input_fields.append(('width', rect))
            elif i == 1:
                self.input_fields.append(('height', rect))
            else:
                self.input_fields.append(('percent', rect))

        self.buttons.append(Button(sw//2 - bw//2, 380, bw, bh, "Играть", self.small_font))
        self.buttons.append(Button(sw//2 - bw//2, 440, bw, bh, "Назад", self.small_font))

    def draw(self):
        overlay = pygame.Surface(self.screen.get_size())
        overlay.set_alpha(180)
        overlay.fill((0, 0, 0))
        self.screen.blit(overlay, (0, 0))

        rect = pygame.Rect(self.screen.get_width()//2 - 200, 20, 400, 510)
        pygame.draw.rect(self.screen, (50, 50, 50), rect)
        pygame.draw.rect(self.screen, (255, 255, 255), rect, 2)

        title = self.font.render("Настройки", True, self.colors['text'])
        tr = title.get_rect(center=(self.screen.get_width()//2, 50))
        self.screen.blit(title, tr)

        for btn in self.buttons:
            btn.draw(self.screen, self.colors)

        for i, (label, y) in enumerate(self.labels):
            label_surf = self.small_font.render(label, True, self.colors['text'])
            label_rect = label_surf.get_rect(midright=(self.screen.get_width()//2 - 60, y))
            self.screen.blit(label_surf, label_rect)

            rect = self.input_rects[i]
            color = (200, 200, 200) if self.active_input == i else (100, 100, 100)
            pygame.draw.rect(self.screen, color, rect)
            pygame.draw.rect(self.screen, (255, 255, 255), rect, 2)

            key = self.input_fields[i][0]
            text = self.input_texts[key]
            surf = self.small_font.render(text, True, (0, 0, 0))
            tr = surf.get_rect(center=rect.center)
            self.screen.blit(surf, tr)

    def handle_events(self):
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if ev.type == pygame.MOUSEMOTION:
                for btn in self.buttons:
                    btn.hovered = btn.rect.collidepoint(ev.pos)

            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                for i, btn in enumerate(self.buttons):
                    if btn.rect.collidepoint(ev.pos):
                        if i == 0:
                            config.CURRENT_THEME = 'dark' if config.CURRENT_THEME == 'light' else 'light'
                            self.colors = config.get_colors()
                            return None
                        elif i == 1:
                            config.SOUND_ENABLED = not config.SOUND_ENABLED
                            self.sound_manager.enabled = config.SOUND_ENABLED
                            self.buttons[1].text = "Звук: Вкл" if config.SOUND_ENABLED else "Звук: Выкл"
                            return None
                        elif i == 2:
                            config.SCREAMER_ENABLED = not config.SCREAMER_ENABLED
                            self.buttons[2].text = "Скример: Вкл" if config.SCREAMER_ENABLED else "Скример: Выкл"
                            return None
                        elif i == 3:
                            self.apply_custom_params()
                            self.running = False
                            return 'play'
                        elif i == 4:
                            self.running = False
                            return 'back'

                for idx, rect in enumerate(self.input_rects):
                    if rect.collidepoint(ev.pos):
                        self.active_input = idx
                        break
                else:
                    self.active_input = None

            if ev.type == pygame.KEYDOWN and self.active_input is not None:
                key = self.input_fields[self.active_input][0]
                if ev.key == pygame.K_BACKSPACE:
                    self.input_texts[key] = self.input_texts[key][:-1]
                elif ev.key == pygame.K_RETURN:
                    self.active_input = None
                elif ev.unicode.isdigit() or ev.unicode == '.':
                    self.input_texts[key] += ev.unicode
        return None

    def apply_custom_params(self):
        try:
            w = int(self.input_texts['width'])
            h = int(self.input_texts['height'])
            p = float(self.input_texts['percent'])
            config.set_custom_params(w, h, p)
        except ValueError:
            pass

    def run(self):
        for key in self.input_texts:
            if self.input_texts[key] == '':
                if key == 'width': self.input_texts[key] = str(config.CUSTOM_SIZE_X)
                elif key == 'height': self.input_texts[key] = str(config.CUSTOM_SIZE_Y)
                elif key == 'percent': self.input_texts[key] = str(config.CUSTOM_MINES_PERCENT)

        while self.running:
            result = self.handle_events()
            if result == 'play':
                return 'play'
            elif result == 'back':
                return 'back'
            self.draw()
            pygame.display.flip()
            pygame.time.Clock().tick(FPS)
        return 'back'


class GameOverMenu:
    def __init__(self, screen, is_win, time_spent, diff_name, diff_key):
        self.screen = screen
        self.is_win = is_win
        self.time_spent = time_spent
        self.diff_name = diff_name
        self.diff_key = diff_key
        self.colors = config.get_colors()
        self.font = pygame.font.Font(None, 48)
        self.small = pygame.font.Font(None, 28)
        self.buttons = []
        sw, sh = screen.get_width(), screen.get_height()
        bw, bh = 150, 40
        self.buttons.append(Button(sw//2 - bw - 20, sh//2 + 40, bw, bh, "Заново", self.small))
        self.buttons.append(Button(sw//2 + 20, sh//2 + 40, bw, bh, "В меню", self.small))

    def draw(self):
        ov = pygame.Surface(self.screen.get_size())
        ov.set_alpha(200)
        ov.fill((0, 0, 0))
        self.screen.blit(ov, (0, 0))

        if self.is_win:
            title = self.font.render("ПОБЕДА!", True, (0, 255, 0))
            time_txt = self.small.render(f"Время: {self.time_spent} сек", True, self.colors['text'])
            diff_txt = self.small.render(f"Сложность: {self.diff_name}", True, self.colors['text'])
            records = load_records()
            if self.diff_key in records:
                best = records[self.diff_key]
                best_txt = self.small.render(f"Рекорд: {best} сек", True, (255, 255, 0))
                br = best_txt.get_rect(center=(self.screen.get_width()//2, self.screen.get_height()//2 + 20))
                self.screen.blit(best_txt, br)
        else:
            title = self.font.render("ИГРА ОКОНЧЕНА!", True, (255, 0, 0))
            time_txt = self.small.render(f"Вы продержались: {self.time_spent} сек", True, self.colors['text'])
            diff_txt = self.small.render(f"Сложность: {self.diff_name}", True, self.colors['text'])

        tr = title.get_rect(center=(self.screen.get_width()//2, self.screen.get_height()//2 - 100))
        self.screen.blit(title, tr)
        tr = time_txt.get_rect(center=(self.screen.get_width()//2, self.screen.get_height()//2 - 40))
        self.screen.blit(time_txt, tr)
        tr = diff_txt.get_rect(center=(self.screen.get_width()//2, self.screen.get_height()//2 - 10))
        self.screen.blit(diff_txt, tr)

        for b in self.buttons:
            b.draw(self.screen, self.colors)

    def run(self):
        while True:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                for i, b in enumerate(self.buttons):
                    if b.handle_event(ev):
                        return 'restart' if i == 0 else 'menu'
            self.draw()
            pygame.display.flip()
            pygame.time.Clock().tick(FPS)


class Menu:
    def __init__(self, screen, music_player, sound_manager):
        self.screen = screen
        self.music_player = music_player
        self.sound_manager = sound_manager
        self.colors = config.get_colors()
        self.font = pygame.font.Font(None, 48)
        self.small_font = pygame.font.Font(None, 24)
        self.medium_font = pygame.font.Font(None, 20)
        self.buttons = []
        self.custom_btn = None
        self.update_custom_button()

        sw, sh = screen.get_width(), screen.get_height()
        bw, bh = 280, 40
        y0 = sh//2 - 100

        self.buttons.append(Button(sw//2 - bw//2, y0, bw, bh, "Лёгкий (10x10, 10 мин)", self.small_font))
        self.buttons.append(Button(sw//2 - bw//2, y0+50, bw, bh, "Средний (15x15, 27 мин)", self.small_font))
        self.buttons.append(Button(sw//2 - bw//2, y0+100, bw, bh, "Сложный (20x20, 60 мин)", self.small_font))
        self.buttons.append(Button(sw//2 - bw//2, y0+150, bw, bh, "ЭКСТРИМ (23x23, 106 мин)", self.small_font))

        self.settings_btn = Button(20, 20, 120, 40, "Настройки", self.small_font)

    def run(self):
        self.music_player.start()
        while True:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    self.music_player.stop()
                    pygame.quit()
                    sys.exit()

                if self.settings_btn.handle_event(ev):
                    self.music_player.stop()
                    settings = SettingsWindow(self.screen, self.music_player, self.sound_manager)
                    result = settings.run()
                    self.music_player.start()
                    if result == 'play':
                        self.music_player.stop()
                        return 'custom'
                    else:
                        self.update_custom_button()
                        self.colors = config.get_colors()
                    continue

                if self.custom_btn and self.custom_btn.handle_event(ev):
                    self.music_player.stop()
                    return 'custom'

                for i, btn in enumerate(self.buttons):
                    if btn.handle_event(ev):
                        self.music_player.stop()
                        difficulties = ['easy', 'medium', 'hard', 'extreme']
                        if i < len(difficulties):
                            return difficulties[i]

            self.screen.fill(self.colors['menu_bg'])
            title = self.font.render("САПЁР", True, self.colors['text'])
            tr = title.get_rect(center=(self.screen.get_width()//2, 80))
            self.screen.blit(title, tr)

            records = load_records()
            y = 130
            if records:
                for key, val in records.items():
                    name = DIFFICULTY_SETTINGS.get(key, {}).get('name', key)
                    if key == 'custom':
                        name = 'Кастомное'
                    txt = self.small_font.render(f"{name}: {val} сек", True, (255, 215, 0))
                    r = txt.get_rect(center=(self.screen.get_width()//2, y))
                    self.screen.blit(txt, r)
                    y += 25
            else:
                txt = self.medium_font.render("Нет рекордов", True, self.colors['text'])
                r = txt.get_rect(center=(self.screen.get_width()//2, 140))
                self.screen.blit(txt, r)

            for btn in self.buttons:
                btn.draw(self.screen, self.colors)

            self.settings_btn.draw(self.screen, self.colors)

            if self.custom_btn:
                self.custom_btn.draw(self.screen, self.colors)

            pygame.display.flip()
            pygame.time.Clock().tick(FPS)

    def update_custom_button(self):
        if (config.CUSTOM_SIZE_X != 10 or config.CUSTOM_SIZE_Y != 10 or config.CUSTOM_MINES_PERCENT != 10):
            sw, sh = self.screen.get_width(), self.screen.get_height()
            self.custom_btn = Button(
                sw - 220, sh - 60, 200, 40,
                "Играть в кастомное поле", self.small_font
            )
        else:
            self.custom_btn = None